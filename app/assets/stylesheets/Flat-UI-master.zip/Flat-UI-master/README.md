Flat UI Free
=======

Flat UI Free is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/) and MIT License - http://opensource.org/licenses/mit-license.html. 

You are allowed to use these elements anywhere you want, however we’ll highly appreciate if you will link to our website when you share them - http://designmodo.com

Thanks for supporting our website and enjoy!

## Links:

+ [Demo page](http://designmodo.github.com/Flat-UI/)
+ [Official page](http://designmodo.com/flat-free)
+ [Premium Version of Flat UI](http://designmodo.com/flat/)

## Changelog

+ 1.0 Fixed several small IE bugs
+ 1.1 New icons, Login screen implemented to a real HTML one. Small bug fixes and refinements.

## Authors

**Sergey Shmidt**

+ [http://shmidt.in](http://shmidt.in)
+ [http://twitter.com/monstercritic](http://twitter.com/monstercritic)

**Sergii Iurevych**

+ [http://twitter.com/iurevych](http://twitter.com/iurevych)
+ [http://github.com/iurevych](http://github.com/iurevych)

## Typeface
Flat UI Free is made using the Lato typeface, which can be downloaded for free here: http://www.google.com/webfonts/specimen/Lato
